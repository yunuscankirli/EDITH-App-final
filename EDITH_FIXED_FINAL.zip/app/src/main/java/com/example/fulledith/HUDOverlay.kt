package com.example.fulledith

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.*

class HUDOverlay @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var isListening = false
    private var volumeLevel = 0f
    private var pulseAngle = 0f
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private val greenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF41")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4400FF41")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF41")
        textSize = 38f
        typeface = Typeface.MONOSPACE
    }

    private val dimTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8800FF41")
        textSize = 28f
        typeface = Typeface.MONOSPACE
    }

    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF41")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    init {
        startAnimation()
    }

    private fun startAnimation() {
        handler.post(object : Runnable {
            override fun run() {
                pulseAngle = (pulseAngle + 3f) % 360f
                invalidate()
                handler.postDelayed(this, 16) // ~60fps
            }
        })
    }

    fun setListening(listening: Boolean) {
        isListening = listening
        invalidate()
    }

    fun setVolume(rms: Float) {
        volumeLevel = (rms + 2f).coerceIn(0f, 12f) / 12f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // ── Köşe çerçeveleri ──────────────────────────────────────
        val cornerLen = 60f
        val margin = 30f
        greenPaint.strokeWidth = 3f

        // Sol üst
        canvas.drawLine(margin, margin, margin + cornerLen, margin, greenPaint)
        canvas.drawLine(margin, margin, margin, margin + cornerLen, greenPaint)
        // Sağ üst
        canvas.drawLine(w - margin, margin, w - margin - cornerLen, margin, greenPaint)
        canvas.drawLine(w - margin, margin, w - margin, margin + cornerLen, greenPaint)
        // Sol alt
        canvas.drawLine(margin, h - margin, margin + cornerLen, h - margin, greenPaint)
        canvas.drawLine(margin, h - margin, margin, h - margin - cornerLen, greenPaint)
        // Sağ alt
        canvas.drawLine(w - margin, h - margin, w - margin - cornerLen, h - margin, greenPaint)
        canvas.drawLine(w - margin, h - margin, w - margin, h - margin - cornerLen, greenPaint)

        // ── Başlık ──────────────────────────────────────────────
        textPaint.textSize = 48f
        canvas.drawText("E.D.I.T.H.", 55f, 95f, textPaint)
        dimTextPaint.textSize = 24f
        canvas.drawText("EVEN DEAD I'M THE HERO", 55f, 125f, dimTextPaint)

        // ── Ses dalgası / Radar çemberi ──────────────────────────
        val cx = w / 2f
        val cy = h / 2f
        val baseRadius = 80f

        if (isListening) {
            // Ses dalgası animasyonu
            for (i in 1..5) {
                val radius = baseRadius + i * 30f + volumeLevel * 40f * sin(Math.toRadians((pulseAngle + i * 20).toDouble())).toFloat()
                circlePaint.alpha = (255 - i * 40).coerceIn(30, 255)
                canvas.drawCircle(cx, cy, radius, circlePaint)
            }
            // Merkez nokta
            greenPaint.style = Paint.Style.FILL
            canvas.drawCircle(cx, cy, 10f, greenPaint)
            greenPaint.style = Paint.Style.STROKE

            // "DİNLİYORUM" yazısı
            textPaint.textSize = 32f
            val listenTxt = "● DİNLİYORUM"
            val tw = textPaint.measureText(listenTxt)
            canvas.drawText(listenTxt, cx - tw / 2, cy + baseRadius + 80f, textPaint)
        } else {
            // Radar tarama çizgisi
            val sweepX = cx + (baseRadius + 60f) * cos(Math.toRadians(pulseAngle.toDouble())).toFloat()
            val sweepY = cy + (baseRadius + 60f) * sin(Math.toRadians(pulseAngle.toDouble())).toFloat()
            greenPaint.strokeWidth = 2f
            canvas.drawLine(cx, cy, sweepX, sweepY, greenPaint)
            canvas.drawCircle(cx, cy, baseRadius + 60f, circlePaint)
        }

        // ── Alt durum bilgisi ────────────────────────────────────
        dimTextPaint.textSize = 26f
        canvas.drawText("SYS: ONLINE  |  AI: AKTIF  |  CAM: HAZIR", 30f, h - 80f, dimTextPaint)
        canvas.drawText("v2.0  |  STARK TECH  |  CLASSIFIED", 30f, h - 50f, dimTextPaint)

        // ── Sağ taraf çubukları ──────────────────────────────────
        val barX = w - 25f
        for (i in 0..9) {
            val barY = h / 2 - 100 + i * 22f
            val barAlpha = if (isListening && i < (volumeLevel * 10).toInt()) 255 else 80
            greenPaint.alpha = barAlpha
            greenPaint.strokeWidth = 8f
            canvas.drawLine(barX - 12f, barY, barX, barY, greenPaint)
        }
        greenPaint.alpha = 255
        greenPaint.strokeWidth = 2f
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacksAndMessages(null)
    }
}
