package com.example.fulledith

/**
 * EDITH İOKBS 2026 — 7. Sınıf Son Gece Tekrar Motoru
 * Sınav: 26 Nisan 2026 Pazar, saat 10:00
 * 80 soru / 100 dakika / 4 ders (her dersten 20 soru)
 * 3 yanlış → 1 doğru götürür
 *
 * Konular (MEB 2026 resmi listesi):
 * MATEMATİK: Tam Sayılar, Rasyonel Sayılar, Cebirsel İfadeler, Oran-Orantı, Doğrular-Açılar
 * TÜRKÇE   : Sözcükte/Cümlede/Parçada Anlam, Yazım, Fiiller, Ekfiil, Noktalama, Metin, Söz Sanatları, Zarflar, Anlatım Bozuklukları, Mantık
 * FEN      : Güneş Sistemi, Hücre, Kuvvet-Enerji, Saf Madde-Karışımlar, Işık-Madde, Elektrik
 * SOSYAL   : Birey-Toplum, Kültür-Miras, İnsanlar-Yerler, Bilim-Teknoloji, Üretim-Dağıtım
 */
object IOKBSCoach {

    data class Soru(
        val ders: String,
        val metin: String,          // Sesli okunacak soru
        val dogruCevap: String,     // Sesten tanınacak anahtar kelime(ler)
        val aciklama: String        // Cevap açıklaması
    )

    // ── MATEMATİK (20 soru hedefi, buraya örnek 8) ───────────────
    val matematik = listOf(
        Soru("Matematik",
            "Eksi 12 artı 5 işleminin sonucu kaçtır?",
            "eksi yedi|−7|-7",
            "−12 + 5 = −7. Büyük sayının işareti alınır, fark hesaplanır."
        ),
        Soru("Matematik",
            "Üçte iki ile dörtte üçün toplamı nedir? Tam sayı ve kesir olarak söyle.",
            "on yedi on iki|bir beşte|1 ve 5 bölü 12",
            "2/3 + 3/4 = 8/12 + 9/12 = 17/12 = 1 ve 5/12."
        ),
        Soru("Matematik",
            "İki x artı 5 eşittir 11 denkleminde x kaçtır?",
            "üç|x=3",
            "2x = 11 − 5 = 6, x = 3."
        ),
        Soru("Matematik",
            "Bir araba 3 saatte 240 kilometre giderse, 5 saatte kaç kilometre gider?",
            "dört yüz|400",
            "Hız = 240/3 = 80 km/s. 5 × 80 = 400 km."
        ),
        Soru("Matematik",
            "Yüzde 25 artış sonucunda 80 lira olan bir ürünün orijinal fiyatı kaç liradır?",
            "altmış dört|64",
            "Orijinal × 1.25 = 80 → Orijinal = 80/1.25 = 64 TL."
        ),
        Soru("Matematik",
            "İki paralel doğruyu kesen bir kesende iç ters açılar birbirine eşit midir?",
            "evet|eşittir|eşit",
            "Evet. İç ters açılar daima birbirine eşittir — bu temel geometri kuralıdır."
        ),
        Soru("Matematik",
            "Bir üçgenin iki açısı 55 ve 70 derece ise üçüncü açı kaç derecedir?",
            "elli beş|55",
            "Üçgen açıları toplamı 180°. 180 − 55 − 70 = 55 derece."
        ),
        Soru("Matematik",
            "3 ile 5 in oranı 4 ile kaçın oranına eşittir? Yani 3 bölü 5 eşittir 4 bölü x; x kaçtır?",
            "yirmi üç bölü üç|6.67|6 virgül 67|yirmi bölü üç",
            "3/5 = 4/x → x = 20/3 ≈ 6.67."
        ),

        // ── TÜRKÇE ───────────────────────────────────────────────
        Soru("Türkçe",
            "Sözcükte anlam sorusu: Aşağıdakilerden hangisi mecaz anlam taşır? Birincisi: Elma topladı. İkincisi: Kalbini kırdı. Üçüncüsü: Kitabı okudu. Dördüncüsü: Eve gitti.",
            "ikinci|kalbini kırdı",
            "'Kalbini kırdı' ifadesinde kalp fiziksel olarak kırılmaz; duygu incitilir. Bu mecaz anlamdır."
        ),
        Soru("Türkçe",
            "Ek-fiil sorusu: 'Öğrenci çalışkandı' cümlesinde ek-fiil hangisidir?",
            "dı|ydı|di",
            "'-dı' eki ek-fiildir. Çalışkan ismine geçmiş zaman anlamı katar."
        ),
        Soru("Türkçe",
            "Yazım kuralı sorusu: 'De' bağlacı ayrı mı, bitişik mi yazılır?",
            "ayrı",
            "'De/da' bağlaç olarak kullanıldığında daima ayrı yazılır. Çıkar değiştirilir ise bağlaçtır."
        ),
        Soru("Türkçe",
            "Anlatım bozukluğu sorusu: 'Kitabı okudum ve beğendim' cümlesinde anlatım bozukluğu var mı?",
            "yok|hayır",
            "Bu cümlede anlatım bozukluğu yoktur. Öge eksikliği veya anlam karmaşası bulunmaz."
        ),
        Soru("Türkçe",
            "Söz sanatı sorusu: 'Güneş gülümsedi' ifadesinde hangi söz sanatı kullanılmıştır?",
            "kişileştirme|teşhis",
            "Güneş insan gibi gülümseyemez; buna kişileştirme (teşhis) denir."
        ),
        Soru("Türkçe",
            "Zarf sorusu: 'Hızlıca koştu' cümlesinde zarf hangisidir?",
            "hızlıca",
            "'Hızlıca' sözcüğü, eylemi 'nasıl' sorusuna cevap vererek nitelediği için hal zarfıdır."
        ),

        // ── FEN BİLİMLERİ ────────────────────────────────────────
        Soru("Fen",
            "Güneş Sistemi sorusu: Güneş'e en yakın gezegen hangisidir?",
            "merkür",
            "Merkür, Güneş'e en yakın gezegendir. Ortalama uzaklığı yaklaşık 58 milyon km'dir."
        ),
        Soru("Fen",
            "Hücre sorusu: Mitoz bölünme sonucunda kaç yavru hücre oluşur ve bunlar ana hücreyle genetik olarak nasıldır?",
            "iki|aynı|özdeş",
            "Mitoz sonucu 2 yavru hücre oluşur. Her ikisi de ana hücreyle genetik olarak özdeştir."
        ),
        Soru("Fen",
            "Kuvvet sorusu: Bir cismin ağırlığı 60 Newton ve kütlesi 6 kilogram ise yerçekimi ivmesi kaç metre bölü saniye karedir?",
            "on|10",
            "g = Ağırlık / Kütle = 60 / 6 = 10 m/s²."
        ),
        Soru("Fen",
            "Karışımlar sorusu: Tuz ve su karışımı hangi yöntemle ayrılır?",
            "buharlaştırma|evaporasyon",
            "Tuz suda çözünür. Buharlaştırma yöntemiyle su uzaklaştırılır, tuz kalır."
        ),
        Soru("Fen",
            "Işık sorusu: Işık saydam bir ortamdan yarı saydam bir ortama geçtiğinde ne olur?",
            "kırılır|yavaşlar|yön değiştirir",
            "Işık farklı ortama geçince hızı değişir ve kırılır; yani yön değiştirir."
        ),

        // ── SOSYAL BİLGİLER ──────────────────────────────────────
        Soru("Sosyal",
            "Birey ve Toplum sorusu: Toplumsal normlar ne anlama gelir?",
            "kural|davranış kuralı|toplumun beklentisi",
            "Toplumsal normlar, bir toplumun üyelerinden beklediği davranış kurallarıdır."
        ),
        Soru("Sosyal",
            "Kültür ve Miras sorusu: UNESCO tarafından korunan somut olmayan kültürel miras neleri kapsar?",
            "gelenek|müzik|dans|el sanatı|sözlü gelenek",
            "Somut olmayan kültürel miras; gelenekler, sözlü ifadeler, müzik, dans, el sanatlarını kapsar."
        ),
        Soru("Sosyal",
            "Üretim ve Dağıtım sorusu: Ahilik teşkilatı hangi alanda faaliyet göstermiştir?",
            "esnaf|zanaat|üretim|ticaret",
            "Ahilik, Anadolu'da esnaf ve zanaatkarları örgütleyen mesleki ve ahlaki bir teşkilattır."
        ),
        Soru("Sosyal",
            "Bilim ve Teknoloji sorusu: Matbaanın Osmanlı'ya girişi hangi yüzyılda gerçekleşmiştir?",
            "on sekizinci|18|1700",
            "Matbaa Osmanlı'ya 18. yüzyılda, 1727'de İbrahim Müteferrika tarafından getirilmiştir."
        )
    )

    // ── Gece tekrar özet metinleri (EDITH sesli okuyacak) ────────
    val geceOzetleri = mapOf(
        "matematik" to listOf(
            "Matematik özeti. Tam sayı işlemlerinde: aynı işaretler toplanır, farklı işaretler çıkarılır.",
            "Rasyonel sayı toplamada paydaları eşitle, payları topla. Çarpmada pay çarpı pay, payda çarpı payda.",
            "Denklem çözerken: bilinmeyeni tek tarafa, sabitleri öbür tarafa al.",
            "Oran ve orantıda: iç terimler çarpımı, dış terimler çarpımına eşittir.",
            "Açılar: düz açı 180, tam açı 360, dik açı 90 derece. İç ters açılar eşittir."
        ),
        "türkçe" to listOf(
            "Türkçe özeti. De bağlacı daima ayrı yazılır. Soru mu eklenirse değişmez, bağlaç kalır.",
            "Mecaz anlam: sözcük gerçek anlamı dışında kullanılır. Kalbini kırdı, ayağını bastı gibi.",
            "Kişileştirme: cansız varlıklara insan özellikleri verilir. Güneş gülümsedi gibi.",
            "Ek-fiil: isim ve sıfatlara eklenerek yüklem yapar. İdi, imiş, ise, iken şekilleri vardır.",
            "Anlatım bozukluğu: öge eksikliği, anlam belirsizliği ve gereksiz sözcük kullanımıdır."
        ),
        "fen" to listOf(
            "Fen özeti. Güneş Sistemi sırası: Merkür, Venüs, Dünya, Mars, Jüpiter, Satürn, Uranüs, Neptün.",
            "Mitoz bölünme: 2 yavru hücre, özdeş DNA. Mayoz bölünme: 4 yavru hücre, farklı DNA.",
            "Newton ikinci yasa: F eşittir m çarpı a. Ağırlık eşittir kütle çarpı g.",
            "Karışım ayırma yöntemleri: Buharlaştırma, süzme, damıtma, mıknatısla ayırma.",
            "Işığın kırılması: ortam değişince ışık hızı değişir ve yön değiştirir."
        ),
        "sosyal" to listOf(
            "Sosyal Bilgiler özeti. Ahilik: Anadolu'da esnaf ve zanaatkar dayanışma örgütüdür.",
            "Osmanlı'da matbaa 1727'de İbrahim Müteferrika tarafından kuruldu.",
            "Somut olmayan kültürel miras: gelenekler, müzik, dans, sözlü ifadeler.",
            "Nüfus artışı: doğum oranı yüksek, ölüm oranı düşükse nüfus artar.",
            "Kültür: bir toplumun yaşam biçimi, değerleri, gelenekleri ve sanatının bütünüdür."
        )
    )

    // ── Sınav sabahı tavsiyeleri ──────────────────────────────────
    val sinavSabahiTavsiyeleri = listOf(
        "Sınav sabahı geldi. Bugün İOKBS var. Saat 10:00'a kadar hazır ol.",
        "Kahvaltını mutlaka yap. Beyin glikoza ihtiyaç duyar.",
        "Yanına kimlik ve giriş belgeni al. Kurşun kalem, silgi ve kalemtıraş gerekiyor.",
        "Sınava en az 30 dakika erken git.",
        "Sınavda 3 yanlış 1 doğruyu götürür. Bilmediğin soruyu boş bırak.",
        "Önce kolay soruları çöz, zor sorulara son bırak.",
        "Matematik ve Fen'in ağırlığı Sosyal'den fazladır. Bu derslere dikkat et.",
        "100 dakikan var, 80 soru. Her soruya ortalama bir buçuk dakika düşer.",
        "Derin bir nefes al. Sen çalıştın, hazırsın. Başarılar dilerim."
    )

    fun rastgeleSoru(ders: String? = null): Soru {
        val havuz = if (ders != null)
            matematik.filter { it.ders.lowercase().contains(ders.lowercase()) }
        else matematik
        return havuz.random()
    }
}
